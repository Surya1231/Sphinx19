# Sphinx'19 Website

*Please see the below link for running instructions after you clone tis repository in your system.*
https://tutorialvilla.com/how/how-to-run-first-php-program-in-xampp-server


**THE LOCATION OF THE PROJECT IN YOUR SYSTEM SHOULD BE C:/xampp/htdocs/**

## Contributers:

