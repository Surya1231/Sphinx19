<?php
if(!$_SESSION["user_sphinx_sp"])
{
	$_SESSION["messagess"]="Please login to continue !";
	header("Location:index.php");

}
else{
	}

 ?>
