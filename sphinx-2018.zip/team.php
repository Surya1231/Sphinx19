<?php
include("config.php");
$db= new Database();
?>

<!DOCTYPE html>

<html class="skrollr skrollr-desktop">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">



<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<title>Sphinx'19</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="icon" type="image/png" href="images/favicon.png">
<link href="css/font-awesome.css" rel="stylesheet" type="text/css">
<link href="css/parsley.css" rel="stylesheet" type="text/css">



<link rel="stylesheet" href="css/main.css">

<link href="css/css" rel="stylesheet">

<script src="js/jquery.min.js"></script>
<link href="css/jquery.fancybox.css" rel="stylesheet" type="text/css">
<link href="css/fancy-modrate.css" rel="stylesheet" type="text/css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">

<link href="css/ticker-style.css" rel="stylesheet" type="text/css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="css/responsive.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/timestamp.js?v=1506980387.0" charset="utf-8"></script>
<script type="text/javascript" src="js/graph-calc.js?v=1506980387.0" charset="utf-8"></script>
<script type="text/javascript" src="js/auto-complete.js?v=1506980387.0" charset="utf-8"></script>
<script type="text/javascript" src="js/toolbar.js?v=1506980387.0" charset="utf-8"></script>

<script type="text/javascript" src="js/jquery.fancybox.js" charset="utf-8"></script>
<script type="text/javascript" src="js/fancy-morate.js" charset="utf-8"></script>


<!-- END WAYBACK TOOLBAR INSERT -->

<script>
$(window).bind("load", function() {
	//alert('hello');
  	$('#overlay').css({'left':'110%', 'transition':'all 1s ease-in-out'}, 2000);

});
</script>


</head>
<body style="overflow:hidden;">

<div id="overlay" style="width:100%;">
	<div class="ppp1" >
		 <div class="ppp2"></div>
		 <div class="ppp3"></div>
	</div>
</div>


<?php
	include('header.php');
?>

   <style>

.card{color:#2A5A88;
 width:60px;
 font-weight:bold;
 padding-top:12px;
 height:60px;
 background-color:#fff;
 border-radius:50%;
 box-shadow:0px 0px 20px 10px #2A5A88;
 display:inline-block;
 font-size:28px;
 }
 .card:hover{
	 color:#fff;
	 background-color:#2A5A88;
	  box-shadow:0px 0px 20px 10px #fff;
 }

 .post_heading{
	 position:fixed;
	 width:100%;
	 top:25px;

	 font-size:25px;
	 font-weight:bold;
	 font-family:text;
	margin-left:-20px;
 }
  .post_heading2{
	 background-color:#fff;
	 width:22%;
	 color:#2A5D88;
	 border-radius:40px;
 }


 .contentbox_pwr {
width: 700px;
position: absolute;

    top: 235px;
    height: auto;
   left:25px;
}
.title_img2{
	position:absolute; width:600px; top:250px; margin:0 auto; right:100px;

}
.title_img{

		position:absolute; width:17%; top:150px; margin:0 auto; left:250px;
}
</style>








               <div id="slide-1" style="width:100%;">
<img src="images/team.png" class="title_img2">



          <img src="images/teamsphinx.png" class="title_img">
<center>
<section class="contentbox_pwr" style="
">
                    <div>
                    <div class="about_box_mainwrp">


<div class="ourtemamanin_wrp">

	<div class="ourtema_marverman_wrp row">
        	<div class="col-sm-12">
            	<div class="ourteamtedablog">

                    <!--p>We understand, how much important is it for you to know who we are and how we approach your business. This page will let you know about the people, who make us a BIG ever expanding family and put efforts regularly to make our company unique to deliever your project with perfection. Let's start the journey...</p-->
                </div>
            </div>
            <div class="col-sm-12">
             <center>	<div class="mervelblock_wrp">
               	<ul>
                  <li>
                    <a data-fancybox data-src="#hidden-content" href="javascript:;" > <div class="card" style="">
                    <span title="Advisor"><i class="fa fa-address-book" aria-hidden="true"></i></span></div> </a>
                    <div id="hidden-content" class="ourtema_de_Wr twoboxPop" style="display:none;">
                       <div class="post_heading">
                       <center>
                       <div class="post_heading2">Advisor</div>
                       </center>
                       </div>

                         <div class="teampoppwrp">
                                     <div class="container">

                         <div class="row">

                         <div class="col-lg-6 col-md-12 col-sm-12">
                        <div class="teamdeatilbox">
                                      <div class="row">
                                        <div class="col-sm-5">
                                          <img src="images/team19/varun.jpg" class="img-fluid" draggable="false">
                                        </div>
                                          <div class="col-sm-7">
                                            <h3>Varun Verma</h3>
                            <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Advisor</span></p>
                                              <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7014578315</p>
                            <p><i class="fa fa-envelope" aria-hidden="true"></i> 2016ucp1368@mnit.ac.in</p>
                                          </div>
                                      </div>
                        </div>
                        </div>
                          </div>
                         </div>
                                  </div>
                </div>
                </li>

                  <li>
                    <a data-fancybox data-src="#hidden-content1" href="javascript:;" > <div class="card" style="">
                    <span title="President"><i class="fa fa-graduation-cap" aria-hidden="true"></i></span></div> </a>
                    <div id="hidden-content1" class="ourtema_de_Wr twoboxPop" style="display:none;">
          						 <div class="post_heading">
          						 <center>
          						 <div class="post_heading2">President</div>
          						 </center>
          						 </div>

          						   <div class="teampoppwrp">
                                     <div class="container">

          						   <div class="row">



          							<div class="col-lg-6 col-md-12 col-sm-12">
          							<div class="teamdeatilbox">
                                     	<div class="row">
                                      	<div class="col-sm-5">
                                     			<img src="images/team19/anuj.jpg" class="img-fluid" draggable="false">
                                     		</div>
                                          <div class="col-sm-7">
                                          	<h3>Anuj Srivastava</h3>
          									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>President</span></p>
                                              <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9588072917</p>
          									<p><i class="fa fa-envelope" aria-hidden="true"></i>2017UCH1743@mnit.ac.in </p>
                                          </div>
                                      </div>
          							</div>
          							</div>
                                        </div>
          						   </div>
                                  </div>
    						</div>
    						</li>


						                    	<li><a data-fancybox data-src="#hidden-content2" href="javascript:;" >
                                  							  <div class="card" style="">
                            <span title="Vice-President"><i class="fa fa-user" aria-hidden="true"></i></span>
						</div>
                        </a>
                         <div id="hidden-content2" class="ourtema_de_Wr twoboxPop" style="display:none;">
						  <div class="post_heading">
						 <center>
						 <div class="post_heading2">Vice-President</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/divyaman.jpeg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Divyaman</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Vice-President</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8963052212</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCE1211@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

							<div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Nupur.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Nupur Malik</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Vice-President</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8700614357</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UAR1567@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>


                              </div>
						   </div>
                        </div>
						</div>
						</li>


                        <li><a  data-fancybox data-src="#hidden-content3" href="javascript:;" >
                        	<div class="card" style="">
                              <span title="General Secretary"><i class="fa fa-user-plus" aria-hidden="true"></i></span>
						</div>
                        </a>


                        <div id="hidden-content3" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">General Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">



							<div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/ansh.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Ansh Khandelwal</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> General Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8518066443</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCH1770@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

                           <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/anushka.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Anushka Jain</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> General Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7424852226</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCH1386@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

						   </div>
						   </div>
                        </div>
						</div>

						</li>


                    	<li><a  data-fancybox data-src="#hidden-content4" href="javascript:;" >
                        	<div class="card" style="">
                              <span title="Joint Secretary"><i class="fa fa-link" aria-hidden="true"></i></span>
						</div>
                        </a>
                         <div id="hidden-content4" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Technical Society</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

                 <div class="col-lg-6 col-md-12 col-sm-12">
                <div class="teamdeatilbox">
                              <div class="row">
                                <div class="col-sm-5">
                                  <img src="images/team19/suryaprakash.jpeg" class="img-fluid" draggable="false">
                                </div>
                                  <div class="col-sm-7">
                                    <h3>Suryaprakash Agarwal </h3>
                    <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> General Secretary</span></p>
                                      <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7016268414</p>
                    <p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uec1231@mnit.ac.in</p>
                                  </div>
                              </div>
                </div>
                </div>

                <div class="col-lg-6 col-md-12 col-sm-12">
                <div class="teamdeatilbox">
                              <div class="row">
                                <div class="col-sm-5">
                                  <img src="images/team19/nayan.jpg" class="img-fluid" draggable="false">
                                </div>
                                  <div class="col-sm-7">
                                    <h3>Nayan Jain</h3>
                    <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> General Secretary</span></p>
                                      <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8279841288</p>
                    <p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uec1447@mnit.ac.in</p>
                                  </div>
                              </div>
                </div>
                </div>

							<div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/DhruvGolani.jpeg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Dhruv Golani</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> Joint Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9619730222</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uec1056@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

							<div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/anjali.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Anjali Jain</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> Joint Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9799947621</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uch1728@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

							<div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/priya.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Priya Kanodia</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span> Joint Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8875731825</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uch1367@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>


						   </div>
						   </div>
                        </div>

						</div>

						</li>
                        <li><a data-fancybox data-src="#hidden-content5" href="javascript:;" >
                        	<div class="card" style="">
                              <span title="Publicity Secretary"><i class="fa fa-bullhorn" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content5" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Publicity Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Suraj.jpeg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Suraj Prakash</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Publicity Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91- 7763898654</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCE1244@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
                           <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Rishabh.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Rishabh Singh</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Publicity Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7742335562</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCH1232@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>





						   </div>
						   </div>
                        </div>
						</div>


						</li>


						 <li><a data-fancybox data-src="#hidden-content6" href="javascript:;" >
                        	<div class="card" style="">
                             <span title="Marketing Secretary"><i class="fa fa-handshake-o" aria-hidden="true" ></i></span>
						</div>
                        </a>
                        <div id="hidden-content6" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Marketing Secretary</div>
						 </center>
						 </div>

						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/parth.png" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Parth Goyal</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Marketing Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9873691490</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UEC1150@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
              <div class="col-lg-6 col-md-12 col-sm-12">
             <div class="teamdeatilbox">
                           <div class="row">
                             <div class="col-sm-5">
                               <img src="images/team19/ayush.jpg" class="img-fluid" draggable="false">
                             </div>
                               <div class="col-sm-7">
                                 <h3>Ayush Singh</h3>
                 <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Marketing Secretary</span></p>
                                   <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9149225262</p>
                 <p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCE1171@mnit.ac.in</p>
                               </div>
                           </div>
             </div>
             </div>





						   </div>
						   </div>
                        </div>
						</div>


						</li>
                        <li><a  data-fancybox data-src="#hidden-content7" href="javascript:;" >
                        	<div class="card" style="">
								<span title="Decoration Secretary"><i class="fa fa-tripadvisor" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content7" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Decoration Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Pritesh.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Pritesh Kumawat</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Decoration Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7610091747</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UAR1747@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
                           <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/umang.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Umang Bhardwaj</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Decoration Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8219263140</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UAR1316@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

						   </div>
						   </div>
                        </div>
						</div>



						</li>







                    	<!-- <li><a  data-fancybox data-src="#hidden-content8" href="javascript:;" >
                        <div class="card" style="">
                              <span title="Design Secretary"><i class="fa fa-paint-brush" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content8" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Design Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">






						   </div>
						   </div>
                        </div>
						</div>



						</li> -->

					<li><a  data-fancybox data-src="#hidden-content9" href="javascript:;" >
                        <div class="card" style="">
                               <span title="Logistic Secretary"><i class="fa fa-motorcycle" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content9" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Logistic Secretary</div>
						 </center>
						 </div>

						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Dhruv.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Dhruv Gupta</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Logistic Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91- 7627073047</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UAR1679@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
                           <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/kshitiz.jpeg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Kshitiz Kain</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Logistic Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8441944621</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UEE1050@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>






						   </div>
						   </div>
                        </div>
						</div>



						</li>


						<li><a  data-fancybox data-src="#hidden-content10" href="javascript:;" >
                        <div class="card" style="">
                             <span title="Finance Secretary"><i class="fa fa-money" aria-hidden="true" ></i></span>
						</div>
                        </a>
                        <div id="hidden-content10" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Finance Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">


						  <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/jonesh.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Jonesh Jain</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Finance Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8871112126</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCH1253@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

						  <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Ritu.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Ritu Chaoudhary</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Finance Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9602412495</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UAR1464@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>

						   </div>
						   </div>
                        </div>
						</div>



						</li>



						<li><a  data-fancybox data-src="#hidden-content11" href="javascript:;" >
                        <div class="card" style="">
                              <span title="Technical Secretary"><i class="fa fa-code" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content11" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Technical Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Nishant.jpeg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Nishant Sharma</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Technical Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9968992525</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UAR1774@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
                           <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/mridul.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Mridul Singhal</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Technical Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9634157767</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UME1352@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
						   </div>
						   </div>
                        </div>
						</div>
						</li>



						 <li><a data-fancybox data-src="#hidden-content14" href="javascript:;" >
                        	<div class="card" style="">
                             <span title="Web-Developer"><i class="fa fa-globe" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content14" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Web-Developer</div>
						 </center>
						 </div>

						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-lg-6 col-md-12 col-sm-12">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/suryaprakash.jpeg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Suryaprakash Agarwal</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Web-Developer</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7016268414</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uec1231@mnit.ac.in</p>
                                </div>
                            </div>

							</div>
              <div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/prastik.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Prastik Gyawali</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Web-Developer</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9680398528</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uec1250@mnit.ac.in</p>
                                </div>
                            </div>

							</div>
              <div class="teamdeatilbox">
                            <div class="row">
                              <div class="col-sm-5">
                                <img src="" class="img-fluid" draggable="false">
                              </div>
                                <div class="col-sm-7">
                                  <h3>Ritika Mor</h3>
                  <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Web-Developer</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i>fill-in</p>
                  <p><i class="fa fa-envelope" aria-hidden="true"></i> fill-in</p>
                                </div>
                            </div>

              </div>
              <div class="team">

              </div>
							</div>
              <div class="col-lg-6 col-md-12 col-sm-12">
             <div class="teamdeatilbox">
                           <div class="row">
                             <div class="col-sm-5">
                               <img src="images/team19/DhruvGolani.jpeg" class="img-fluid" draggable="false">
                             </div>
                               <div class="col-sm-7">
                                 <h3>Dhruv Golani</h3>
                 <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Web-Developer</span></p>
                                   <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9619730222</p>
                 <p><i class="fa fa-envelope" aria-hidden="true"></i> 2017uec1056@mnit.ac.in</p>
                               </div>
                           </div>


             </div>

             <div class="teamdeatilbox">
                           <div class="row">
                             <div class="col-sm-5">
                               <img src="images/team19/anmol.jpg" class="img-fluid" draggable="false">
                             </div>
                               <div class="col-sm-7">
                                 <h3>Anmol Mittal</h3>
                 <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Web-Developer</span></p>
                                   <p><i class="fa fa-phone" aria-hidden="true"></i> +91-7895200248</p>
                 <p><i class="fa fa-envelope" aria-hidden="true"></i> 2017umt1501@mnit.ac.in</p>
                               </div>
                           </div>

             </div>
             <div class="teamdeatilbox">
                           <div class="row">
                             <div class="col-sm-5">
                               <img src="images/team19/saloni.jpeg" class="img-fluid" draggable="false">
                             </div>
                               <div class="col-sm-7">
                                 <h3>Saloni Goyal</h3>
                 <p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Web-Developer</span></p>
                                   <p><i class="fa fa-phone" aria-hidden="true"></i>+91-9782630559</p>
                 <p><i class="fa fa-envelope" aria-hidden="true"></i> 2017ucp1061@mnit.ac.in</p>
                               </div>
                           </div>

             </div>

						   </div>
						   </div>
                        </div>
						</div>
						</li>


						<li><a  data-fancybox data-src="#hidden-content12" href="javascript:;" >
                        <div class="card" style="">
                              <span title="Mass and Media Secretary"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content12" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Mass & Media Secretary</div>
						 </center>
						 </div>

						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/arunanshu.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Arunanshu Deep Barnawal</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Mass and Media Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8696913951</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCH1687@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
                           <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/prasanna.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Prasanna Venkatesh V</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Mass and Media Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91- 9834017568</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UMT1748@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>







						   </div>
						   </div>
                        </div>
						</div>



						</li>


									<li><a  data-fancybox data-src="#hidden-content13" href="javascript:;" >
                        <div class="card" style="">
                             <span title="Cultural Secretary"><i class="fa fa-headphones" aria-hidden="true"></i></span>
						</div>
                        </a>
                        <div id="hidden-content13" class="ourtema_de_Wr twoboxPop" style="display:none;">
						   <div class="post_heading">
						 <center>
						 <div class="post_heading2">Cultural Secretary</div>
						 </center>
						 </div>
						 <div class="teampoppwrp">
                           <div class="container">
						   <div class="row">

						   <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Devanshu.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Devanshu Khandal</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Cultural Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-9314655304</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UME1490@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>
                          <div class="col-sm-6">
							<div class="teamdeatilbox">
                           	<div class="row">
                            	<div class="col-sm-5">
                           			<img src="images/team19/Srividya.jpg" class="img-fluid" draggable="false">
                           		</div>
                                <div class="col-sm-7">
                                	<h3>Bhuvanagiri Venkata Srividya</h3>
									<p><i class="fa fa-briefcase" aria-hidden="true"></i> <span>Cultural Secretary</span></p>
                                    <p><i class="fa fa-phone" aria-hidden="true"></i> +91-8639261222</p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> 2017UCP1011@mnit.ac.in</p>
                                </div>
                            </div>
							</div>
							</div>






						   </div>
						   </div>
                        </div>
						</div>



						</li>
					</ul>

                </div></center>
            </div>

    </div>
</div>





</div>

                    </div>
                    </section>
                    </center>


              </div>






























                    </div>
                </div>



  <?php
	include('footer.php');
?>


    </body>
</html>
